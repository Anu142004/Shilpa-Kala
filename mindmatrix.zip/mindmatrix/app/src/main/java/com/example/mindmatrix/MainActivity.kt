package com.example.mindmatrix

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Help
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.net.toUri
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import com.example.mindmatrix.ui.theme.MindmatrixTheme
import kotlinx.coroutines.launch
import java.util.UUID

// Updated Warm Color Palette
val DeepMaroon = Color(0xFF3E2723)
val OchreGold = Color(0xFFBC812C)
val CreamWhite = Color(0xFFFFFBF0) 
val SoftGray = Color(0xFFF5EBDC)   
val WarmBrown = Color(0xFF5D4037)
val WarmGray = Color(0xFF9E8E8A)
val WarmRed = Color(0xFFBA1A1A)
val SuccessGreen = Color(0xFF388E3C)

// Order Status Enum
enum class OrderStatus {
    PENDING,
    APPROVED, 
    DECLINED  
}

// Data Model
data class Sculpture(
    val id: String,
    val title: String,
    val artist: String,
    val collection: String,
    val imageUrl: String,
    val workId: String,
    val material: String,
    val description: String,
    val price: String,
    val category: String,
    val badge: String? = null,
    val progress: Int = 0,
    val estCompletion: String = "N/A",
    val contactNumber: String = "+91 9876543210",
    val status: OrderStatus = OrderStatus.PENDING
)

// Sample Data
val sampleSculptures = listOf(
    Sculpture(
        id = "1",
        title = "The Eternal Dancer",
        artist = "K. Viswakarma",
        collection = "Hoysala Heritage",
        imageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuBrVNBUTgyQBTGqkNOWRZe967du54s8H5dRGJ5p91BwuXcVLr_jLJOhwJma2QdE2ukhVQiNLPBQD8d_l8Of2xQuSaDvLxSpflw-H2yj-rVD3EK-Rkfn4j4Udc5ZvdpEQf4xwx6nves9V3f4Wht4YEoOdob5IoeXo1g0WOXtUE1CtyXIKwFoVhDY6GQS1yLQ3wc6X7brXWkYrhSrCPM26gfiJyEzu9Ybe6Z0H3vPyHUcaG00tVkzo7D06tPZCBWCl1SL4CNcoeWE_7nI",
        workId = "HK-2024-01",
        material = "SANDSTONE",
        description = "A classical interpretation of temple motifs, capturing fluid motion in solid rock.",
        price = "₹1,25,000",
        category = "Temple Sculptures",
        progress = 68,
        estCompletion = "October 2024"
    ),
    Sculpture(
        id = "2",
        title = "Dhyana Ganesha",
        artist = "Arjan Shilpi",
        collection = "Sacred Idols",
        imageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuBVhLdHuTJSw9_kLEmv8efU7yA1yD4rT89jIjQmEtTapL4x6kb71uRrS4fwcZGAMrKvqgLN-b0HReVlj8QcPejwy5DB5CpVw1REF5ee6MdsjYy9TwITMiUFB13WZ0IJJ-e3ePC70TQKAUsHOe4BOZ5lZe8VcQchyRxOTOLpEUyM7WvjgGGl4NdfJkuNWRkVu2qIjTd2mQsVTx0peZf0NE2HV7dqUHaiKcJxWLmE75A_5QeiFp3LH8-J3JLsJk3IW1FRvVzRYWUh4WrP",
        workId = "HK-2024-02",
        material = "MARBLE",
        description = "A serene hand-carved soapstone idol of Lord Ganesha in deep meditation.",
        price = "₹75,000",
        category = "Gods & Goddesses",
        progress = 100,
        estCompletion = "Completed"
    ),
    Sculpture(
        id = "3",
        title = "Sahasrara Lotus",
        artist = "Studio Collection",
        collection = "Sacred Geometry",
        imageUrl = "https://lh3.googleusercontent.com/AB6AXuBXrLInw7U-wF3FAUzOg544w9p10TB72fWhfdeGj1bieKDKMpCtaEZ93O84Pwv2-SKcl5k3wRVQC-_fH9zk8q_EnXWS03J0ziK5dETxoZeV4wuJShbBKoKvaDNmxN1Z-QMYeUjwnUpCqY50NB3rAcL7BFvdP53W70U_23GitHXLeNgX4salqGqyvRZvrVWALx7XsX4A0xBy_umJaAPSGr_vembEmJaG_elzmjCzSYmKdf6nfaywwJCH1COACj316SKHfUN-GlSKdS68",
        workId = "HK-2024-03",
        material = "MARBLE",
        description = "Detailed carving of a lotus flower in white marble, representing divine purity.",
        price = "₹45,000",
        category = "Decorative Art",
        progress = 100,
        estCompletion = "Completed"
    ),
    Sculpture(
        id = "4",
        title = "Modern Heritage Relief",
        artist = "Elena Thorne",
        collection = "Abstract Forms",
        imageUrl = "https://lh3.googleusercontent.com/AB6AXuBapxcRcNiS_bHkOZKyIcg3PCC8NOUeYK4aLc7D0B2dldRTq1HjDbcZNBgJ6aBzwscHhYp0Opa6kljntIaUJT0ZTkF2Cv8skVN4SvY3HoVtIVUOgFpEFjdTc1KcVtINmUwKSOz-fDjkbe0pYd8Wufc6uiMHPmy8ll0te1Ik0EGFsVx5WkJKMqKcoNOWXyZhMlazSHKKsCnywd45ywjSNP_TPKPVu_nCRjzJX21IDxil7I09CaZurF2vQ_47CkR5qqgENa5RyCFsq7L8",
        workId = "HK-2024-05",
        material = "BASALT",
        description = "An abstract wall relief blending modern minimalist forms with traditional textures.",
        price = "₹1,85,000",
        category = "Custom Orders",
        progress = 100,
        estCompletion = "Completed"
    )
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MindmatrixTheme {
                ShilpaKalaApp()
            }
        }
    }
}

@Composable
fun ShilpaKalaApp() {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val orderedItems = remember { mutableStateListOf<Sculpture>() }
    val artistItems = remember { mutableStateListOf<Sculpture>() }
    
    // Hoisted Auth State
    var isLoggedIn by rememberSaveable { mutableStateOf(false) }
    var userName by rememberSaveable { mutableStateOf("") }
    var userEmail by rememberSaveable { mutableStateOf("") }
    var userAddress by rememberSaveable { mutableStateOf("") }

    val context = LocalContext.current

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = CreamWhite,
                drawerShape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp)
            ) {
                Spacer(Modifier.height(48.dp))
                Text(
                    "Heritage Menu",
                    modifier = Modifier.padding(24.dp),
                    style = MaterialTheme.typography.headlineSmall,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    color = DeepMaroon
                )
                HorizontalDivider(modifier = Modifier.padding(horizontal = 24.dp), color = SoftGray)
                Spacer(Modifier.height(16.dp))
                
                NavigationDrawerItem(
                    label = { Text("HOME", fontWeight = FontWeight.Bold, letterSpacing = 1.sp) },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        navController.navigate("home") {
                            popUpTo(navController.graph.startDestinationId) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    icon = { Icon(Icons.Default.Home, null) },
                    colors = NavigationDrawerItemDefaults.colors(
                        unselectedTextColor = DeepMaroon,
                        unselectedIconColor = OchreGold
                    ),
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("ARTISTS", fontWeight = FontWeight.Bold, letterSpacing = 1.sp) },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        navController.navigate("artists") {
                            launchSingleTop = true
                        }
                    },
                    icon = { Icon(Icons.Default.Brush, null) },
                    colors = NavigationDrawerItemDefaults.colors(
                        unselectedTextColor = DeepMaroon,
                        unselectedIconColor = OchreGold
                    ),
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("ORDERS", fontWeight = FontWeight.Bold, letterSpacing = 1.sp) },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        navController.navigate("orders") {
                            launchSingleTop = true
                        }
                    },
                    icon = { Icon(Icons.AutoMirrored.Filled.ReceiptLong, null) },
                    colors = NavigationDrawerItemDefaults.colors(
                        unselectedTextColor = DeepMaroon,
                        unselectedIconColor = OchreGold
                    ),
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
            }
        }
    ) {
        Scaffold(
            topBar = { 
                TopAppBarComponent(
                    navController = navController, 
                    isLoggedIn = isLoggedIn,
                    onSignInClick = { navController.navigate("profile") },
                    onMenuClick = { scope.launch { drawerState.open() } }
                ) 
            },
            bottomBar = { BottomNavBarComponent(navController, orderedItems.size) },
            floatingActionButton = { WhatsAppFAB() }
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = "home",
                modifier = Modifier.padding(innerPadding)
            ) {
                composable("home") { HeritageScreen(navController, isLoggedIn, onSignInClick = { navController.navigate("profile") }) }
                composable("gallery") { GalleryScreen(navController) }
                composable("artists") { ArtistsScreen(artistItems, navController) }
                composable("orders") { 
                    OrdersScreen(
                        orderedItems = orderedItems, 
                        navController = navController,
                        onCancelOrder = { sculpture -> orderedItems.remove(sculpture) }
                    ) 
                }
                composable("profile") { 
                    ProfileScreen(
                        isLoggedIn = isLoggedIn,
                        name = userName,
                        email = userEmail,
                        address = userAddress,
                        orderCount = orderedItems.size,
                        onLogin = { email, password, name, address ->
                            userEmail = email
                            userName = name
                            userAddress = address
                            isLoggedIn = true
                            Toast.makeText(context, "Welcome, $userName!", Toast.LENGTH_SHORT).show()
                        },
                        onLogout = {
                            isLoggedIn = false
                            userName = ""
                            userEmail = ""
                            userAddress = ""
                        }
                    ) 
                }
                composable(
                    "detail/{sculptureId}",
                    arguments = listOf(navArgument("sculptureId") { type = NavType.StringType })
                ) { backStackEntry ->
                    val sculptureId = backStackEntry.arguments?.getString("sculptureId")
                    val sculpture = (sampleSculptures + artistItems).find { it.id == sculptureId }
                    if (sculpture != null) {
                        val currentOrder = orderedItems.find { it.id == sculpture.id }
                        DetailScreen(
                            sculpture = currentOrder ?: sculpture, 
                            initiallyOrdered = currentOrder != null,
                            onBackClick = { navController.popBackStack() },
                            onOrderPlaced = { 
                                if (!orderedItems.any { it.id == sculpture.id }) {
                                    orderedItems.add(sculpture.copy(status = OrderStatus.PENDING))
                                }
                            },
                            onOrderRemoved = {
                                orderedItems.removeAll { it.id == sculpture.id }
                            }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarComponent(
    navController: NavController, 
    isLoggedIn: Boolean, 
    onSignInClick: () -> Unit,
    onMenuClick: () -> Unit = {}
) {
    CenterAlignedTopAppBar(
        title = {
            Text(
                "Shilpa Kala",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                letterSpacing = 1.sp,
                color = DeepMaroon
            )
        },
        navigationIcon = {
            IconButton(onClick = onMenuClick) { Icon(Icons.Default.Menu, "Menu", tint = DeepMaroon) }
        },
        actions = {
            if (!isLoggedIn) {
                TextButton(onClick = onSignInClick) {
                    Text("SIGN IN", color = OchreGold, fontWeight = FontWeight.Bold)
                }
            } else {
                IconButton(onClick = { navController.navigate("profile") }) {
                    Icon(Icons.Default.AccountCircle, "Profile", tint = DeepMaroon)
                }
            }
        },
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = CreamWhite)
    )
}

@Composable
fun BottomNavBarComponent(navController: NavController, orderCount: Int) {
    NavigationBar(containerColor = CreamWhite, tonalElevation = 8.dp) {
        val navBackStackEntry = navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry.value?.destination?.route

        val items = listOf(
            Triple("home", Icons.Default.Home, "Home"),
            Triple("artists", Icons.Default.Brush, "Artists"),
            Triple("orders", Icons.AutoMirrored.Filled.ReceiptLong, "Orders"),
            Triple("profile", Icons.Default.Person, "Profile")
        )

        items.forEach { (route, icon, label) ->
            NavigationBarItem(
                icon = {
                    BadgedBox(
                        badge = {
                            if (route == "orders" && orderCount > 0) {
                                Badge { Text(orderCount.toString()) }
                            }
                        }
                    ) {
                        Icon(icon, label)
                    }
                },
                label = { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                selected = currentRoute == route,
                onClick = {
                    if (currentRoute != route) {
                        navController.navigate(route) {
                            popUpTo(navController.graph.startDestinationId) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = DeepMaroon,
                    selectedTextColor = DeepMaroon,
                    unselectedIconColor = WarmGray,
                    unselectedTextColor = WarmGray,
                    indicatorColor = OchreGold.copy(alpha = 0.2f)
                )
            )
        }
    }
}

@Composable
fun WhatsAppFAB() {
    val context = LocalContext.current
    val whatsappLink = stringResource(R.string.whatsapp_group_link)
    ExtendedFloatingActionButton(
        onClick = {
            val intent = Intent(Intent.ACTION_VIEW, whatsappLink.toUri())
            context.startActivity(intent)
        },
        containerColor = Color(0xFF25D366),
        contentColor = CreamWhite,
        shape = CircleShape,
        icon = { Icon(Icons.AutoMirrored.Filled.Chat, null) },
        text = { Text("WhatsApp Community", style = MaterialTheme.typography.labelSmall) }
    )
}

@Composable
fun HeritageScreen(navController: NavController, isLoggedIn: Boolean, onSignInClick: () -> Unit) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    val categories = listOf("All", "Gods & Goddesses", "Temple Sculptures", "Decorative Art", "Custom Orders")

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(CreamWhite)
    ) {
        item { HeroBanner() }
        
        if (!isLoggedIn) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = OchreGold.copy(alpha = 0.1f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Unlock Heritage Tracking", fontWeight = FontWeight.Bold, color = DeepMaroon)
                            Text("Sign in to track orders and save your favorites.", fontSize = 12.sp, color = WarmGray)
                        }
                        Button(
                            onClick = onSignInClick,
                            colors = ButtonDefaults.buttonColors(containerColor = DeepMaroon),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Sign In", fontSize = 12.sp, color = CreamWhite)
                        }
                    }
                }
            }
        }

        item { 
            SearchBar(query = searchQuery, onQueryChange = { searchQuery = it }) 
        }
        item { 
            CategorySection(categories, selectedCategory) { selectedCategory = it } 
        }
        item { 
            Text(
                "Exclusive Collections",
                modifier = Modifier.padding(16.dp),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = DeepMaroon
            ) 
        }

        val filteredSculptures = sampleSculptures.filter {
            (selectedCategory == "All" || it.category == selectedCategory) &&
            (searchQuery.isEmpty() || it.title.contains(searchQuery, ignoreCase = true))
        }

        itemsIndexed(filteredSculptures) { index, sculpture ->
            AnimatedCard(index) {
                SculptureCard(sculpture) {
                    navController.navigate("detail/${sculpture.id}")
                }
            }
        }
        item { HeritageStorySection() }
        item { Spacer(modifier = Modifier.height(100.dp)) }
    }
}

@Composable
fun HeroBanner() {
    Box(
        modifier = Modifier.fillMaxWidth().height(240.dp).padding(16.dp).clip(RoundedCornerShape(24.dp))
    ) {
        AsyncImage(
            model = "https://lh3.googleusercontent.com/aida-public/AB6AXuBrVNBUTgyQBTGqkNOWRZe967du54s8H5dRGJ5p91BwuXcVLr_jLJOhwJma2QdE2ukhVQiNLPBQD8d_l8Of2xQuSaDvLxSpflw-H2yj-rVD3EK-Rkfn4j4Udc5ZvdpEQf4xwx6nves9V3f4Wht4YEoOdob5IoeXo1g0WOXtUE1CtyXIKwFoVhDY6GQS1yLQ3wc6X7brXWkYrhSrCPM26gfiJyEzu9Ybe6Z0H3vPyHUcaG00tVkzo7D06tPZCBWCl1SL4CNcoeWE_7nI",
            contentDescription = "Stone Carving Heritage",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color.Transparent, DeepMaroon.copy(alpha = 0.8f)))
            )
        )
        Column(modifier = Modifier.align(Alignment.BottomStart).padding(24.dp)) {
            Text(
                "Centuries of Craftsmanship",
                color = CreamWhite,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif
            )
            Text(
                "Bringing traditional stone carving to the modern era.",
                color = CreamWhite.copy(alpha = 0.8f),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchBar(query: String, onQueryChange: (String) -> Unit) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        placeholder = { Text("Search masterpiece...", color = WarmGray) },
        leadingIcon = { Icon(Icons.Default.Search, null, tint = WarmGray) },
        shape = RoundedCornerShape(50.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = OchreGold,
            unfocusedBorderColor = SoftGray,
            focusedContainerColor = CreamWhite,
            unfocusedContainerColor = CreamWhite
        ),
        singleLine = true
    )
}

@Composable
fun CategorySection(categories: List<String>, selected: String, onSelect: (String) -> Unit) {
    LazyRow(
        modifier = Modifier.padding(vertical = 12.dp),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(categories) { category ->
            ModernRoundedButton(
                text = category,
                isSelected = selected == category,
                onClick = { onSelect(category) }
            )
        }
    }
}

@Composable
fun ModernRoundedButton(text: String, isSelected: Boolean, onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(if (isPressed) 0.95f else 1f)

    Surface(
        onClick = onClick,
        interactionSource = interactionSource,
        modifier = Modifier.scale(scale).graphicsLayer {
            shadowElevation = if (isSelected) 6.dp.toPx() else 1.dp.toPx()
        },
        color = if (isSelected) DeepMaroon else CreamWhite,
        contentColor = if (isSelected) CreamWhite else DeepMaroon,
        shape = RoundedCornerShape(50.dp),
        border = BorderStroke(1.dp, if (isSelected) Color.Transparent else SoftGray)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.SansSerif
        )
    }
}

@Composable
fun SculptureCard(
    sculpture: Sculpture, 
    showStatus: Boolean = false,
    onCancelClick: (() -> Unit)? = null, 
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp).clickable { onClick() },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = CreamWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column {
            Box {
                AsyncImage(
                    model = sculpture.imageUrl,
                    contentDescription = sculpture.title,
                    modifier = Modifier.fillMaxWidth().height(220.dp),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier.align(Alignment.TopEnd).padding(12.dp).background(OchreGold, RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(sculpture.category.uppercase(), color = CreamWhite, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
                
                if (showStatus) {
                    Box(
                        modifier = Modifier.align(Alignment.TopStart).padding(12.dp)
                    ) {
                        OrderStatusFlag(sculpture.status)
                    }
                }
            }
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        sculpture.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = DeepMaroon
                    )
                    Text(
                        sculpture.price,
                        style = MaterialTheme.typography.titleMedium,
                        color = OchreGold,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    sculpture.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = WarmBrown,
                    maxLines = 2,
                    lineHeight = 20.sp
                )
                Spacer(modifier = Modifier.height(20.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = onClick,
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DeepMaroon)
                    ) {
                        Text("View Details", fontWeight = FontWeight.Bold, color = CreamWhite)
                    }
                    
                    if (onCancelClick != null) {
                        OutlinedButton(
                            onClick = onCancelClick,
                            modifier = Modifier.height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, WarmRed),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = WarmRed)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Cancel")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OrderStatusFlag(status: OrderStatus) {
    val (color, text) = when (status) {
        OrderStatus.PENDING -> WarmGray to "PENDING"
        OrderStatus.APPROVED -> SuccessGreen to "GOOD TO GO"
        OrderStatus.DECLINED -> WarmRed to "NOT GOOD"
    }
    
    Surface(
        color = color.copy(alpha = 0.9f),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.shadow(4.dp, RoundedCornerShape(8.dp))
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Icon(
                imageVector = if (status == OrderStatus.APPROVED) Icons.Default.CheckCircle 
                             else if (status == OrderStatus.DECLINED) Icons.Default.Error
                             else Icons.Default.Info,
                contentDescription = null,
                tint = CreamWhite,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                color = CreamWhite,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
fun HeritageStorySection() {
    Column(
        modifier = Modifier.fillMaxWidth().padding(16.dp).background(SoftGray, RoundedCornerShape(24.dp)).padding(24.dp)
    ) {
        Text(
            "Our Legacy",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Serif,
            color = DeepMaroon
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            "Shilpa Kala is not just an app; it''s a bridge between the ancient chisel and the modern screen. We blend traditional Indian heritage aesthetics with modern mobile app UI/UX design to bring the sacred art of stone carving to your fingertips.",
            style = MaterialTheme.typography.bodyMedium,
            color = WarmBrown,
            lineHeight = 24.sp
        )
    }
}

@Composable
fun AnimatedCard(index: Int, content: @Composable () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }
    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(animationSpec = tween(500, delayMillis = index * 100)) { it / 2 } + fadeIn(),
        content = { content() }
    )
}

@Composable
fun GalleryScreen(navController: NavController) {
    LazyColumn(modifier = Modifier.fillMaxSize().background(CreamWhite)) {
        item {
            Column(Modifier.padding(24.dp)) {
                Text("Masterpiece Gallery", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif, color = DeepMaroon)
                Text("Explore our complete archive of hand-carved excellence.", color = WarmGray, style = MaterialTheme.typography.bodyMedium)
            }
        }
        items(sampleSculptures) { sculpture ->
            SculptureCard(sculpture) {
                navController.navigate("detail/${sculpture.id}")
            }
        }
        item { Spacer(modifier = Modifier.height(100.dp)) }
    }
}

@Composable
fun OrdersScreen(
    orderedItems: SnapshotStateList<Sculpture>, 
    navController: NavController, 
    onCancelOrder: (Sculpture) -> Unit
) {
    var sculptureToCancel by remember { mutableStateOf<Sculpture?>(null) }

    if (sculptureToCancel != null) {
        AlertDialog(
            onDismissRequest = { sculptureToCancel = null },
            title = { Text("Cancel Order") },
            text = { Text("Are you sure you want to cancel the order for ${sculptureToCancel?.title}?") },
            confirmButton = {
                TextButton(onClick = {
                    onCancelOrder(sculptureToCancel!!)
                    sculptureToCancel = null
                }) {
                    Text("Yes", color = WarmRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { sculptureToCancel = null }) {
                    Text("No")
                }
            }
        )
    }

    if (orderedItems.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().background(CreamWhite), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.AutoMirrored.Filled.ReceiptLong, null, modifier = Modifier.size(64.dp), tint = SoftGray)
                Spacer(modifier = Modifier.height(16.dp))
                Text("No items ordered yet.", color = WarmGray, style = MaterialTheme.typography.bodyLarge)
                Spacer(modifier = Modifier.height(24.dp))
                Button(onClick = { navController.navigate("home") }, colors = ButtonDefaults.buttonColors(containerColor = DeepMaroon)) {
                    Text("Explore Sculptures", color = CreamWhite)
                }
            }
        }
    } else {
        LazyColumn(modifier = Modifier.fillMaxSize().background(CreamWhite)) {
            item {
                Column(Modifier.padding(24.dp)) {
                    Text("My Orders", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif, color = DeepMaroon)
                    Text("Tracking your hand-carved heritage.", color = WarmGray, style = MaterialTheme.typography.bodyMedium)
                }
            }
            items(orderedItems) { sculpture ->
                SculptureCard(
                    sculpture = sculpture,
                    showStatus = true,
                    onCancelClick = { sculptureToCancel = sculpture }
                ) {
                    navController.navigate("detail/${sculpture.id}")
                }
            }
            
            item {
                Column(modifier = Modifier.padding(24.dp).background(SoftGray, RoundedCornerShape(16.dp)).padding(16.dp)) {
                    Text("Owner Demo (Simulation)", style = MaterialTheme.typography.titleSmall, color = DeepMaroon)
                    Text("In a real app, the owner would set these flags from their dashboard.", style = MaterialTheme.typography.bodySmall, color = WarmGray)
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { 
                                orderedItems.forEachIndexed { i, s -> orderedItems[i] = s.copy(status = OrderStatus.APPROVED) } 
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)
                        ) { Text("Approve All", fontSize = 10.sp, color = CreamWhite) }
                        Button(
                            onClick = { 
                                orderedItems.forEachIndexed { i, s -> orderedItems[i] = s.copy(status = OrderStatus.DECLINED) } 
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = WarmRed)
                        ) { Text("Decline All", fontSize = 10.sp, color = CreamWhite) }
                    }
                }
            }
            
            item { Spacer(modifier = Modifier.height(100.dp)) }
        }
    }
}

@Composable
fun DetailScreen(
    sculpture: Sculpture, 
    initiallyOrdered: Boolean, 
    onBackClick: () -> Unit, 
    onOrderPlaced: () -> Unit,
    onOrderRemoved: () -> Unit
) {
    val scrollState = rememberScrollState()
    val context = LocalContext.current
    var isOrdered by remember { mutableStateOf(initiallyOrdered) }
    var showUndoDialog by remember { mutableStateOf(false) }

    if (showUndoDialog) {
        AlertDialog(
            onDismissRequest = { showUndoDialog = false },
            title = { Text("Undo Inquiry") },
            text = { Text("Do you want to remove the inquiry for ${sculpture.title}?") },
            confirmButton = {
                TextButton(onClick = {
                    isOrdered = false
                    onOrderRemoved()
                    showUndoDialog = false
                    Toast.makeText(context, "Inquiry removed", Toast.LENGTH_SHORT).show()
                }) {
                    Text("Yes", color = WarmRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { showUndoDialog = false }) {
                    Text("No")
                }
            }
        )
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(scrollState).background(CreamWhite)
    ) {
        Box {
            AsyncImage(
                model = sculpture.imageUrl,
                contentDescription = sculpture.title,
                modifier = Modifier.fillMaxWidth().height(450.dp),
                contentScale = ContentScale.Crop
            )
            IconButton(
                onClick = onBackClick,
                modifier = Modifier.padding(16.dp).background(CreamWhite.copy(alpha = 0.5f), CircleShape)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = DeepMaroon)
            }
            
            if (isOrdered) {
                Box(modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)) {
                    OrderStatusFlag(sculpture.status)
                }
            }
        }
        Column(modifier = Modifier.padding(24.dp)) {
            Text(
                sculpture.category.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = OchreGold,
                letterSpacing = 2.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text(
                    sculpture.title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    color = DeepMaroon,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    sculpture.price,
                    style = MaterialTheme.typography.headlineSmall,
                    color = OchreGold,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                "About this piece",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = DeepMaroon
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                sculpture.description,
                style = MaterialTheme.typography.bodyLarge,
                lineHeight = 28.sp,
                color = WarmBrown
            )
            Spacer(modifier = Modifier.height(32.dp))
            
            if (sculpture.status != OrderStatus.PENDING) {
                Surface(
                    color = (if (sculpture.status == OrderStatus.APPROVED) SuccessGreen else WarmRed).copy(alpha = 0.1f),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    val statusText = if (sculpture.status == OrderStatus.APPROVED) 
                                "Owner confirmed: This piece is good to go!" 
                               else "Owner update: This inquiry cannot be fulfilled at this time."
                    val statusColor = if (sculpture.status == OrderStatus.APPROVED) SuccessGreen else WarmRed
                    
                    Text(
                        text = statusText,
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = statusColor,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Button(
                onClick = { 
                    if (!isOrdered) {
                        isOrdered = true
                        onOrderPlaced()
                        Toast.makeText(context, "Inquiry placed for ${sculpture.title}", Toast.LENGTH_SHORT).show()
                        
                        val message = "Hello, I am interested in ${sculpture.title} (${sculpture.workId})"
                        val intent = Intent(Intent.ACTION_VIEW, "https://wa.me/919876543210?text=${Uri.encode(message)}".toUri())
                        context.startActivity(intent)
                    } else {
                        showUndoDialog = true
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isOrdered) OchreGold else DeepMaroon
                )
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isOrdered) Icon(Icons.AutoMirrored.Filled.Undo, null, modifier = Modifier.size(20.dp), tint = CreamWhite)
                    else Icon(Icons.Default.ShoppingCart, null, modifier = Modifier.size(20.dp), tint = CreamWhite)
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        if (isOrdered) "UNDO INQUIRY: ${sculpture.title.uppercase()}"
                        else "ORDER INQUIRY: ${sculpture.title.uppercase()}", 
                        fontWeight = FontWeight.Bold, 
                        letterSpacing = 1.sp,
                        color = CreamWhite
                    )
                }
            }
            Spacer(modifier = Modifier.height(100.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    isLoggedIn: Boolean,
    name: String,
    email: String,
    address: String,
    orderCount: Int,
    onLogin: (String, String, String, String) -> Unit,
    onLogout: () -> Unit
) {
    val whatsappLink = stringResource(R.string.whatsapp_group_link)
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CreamWhite)
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "My Heritage Profile",
            style = MaterialTheme.typography.headlineMedium,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            color = DeepMaroon
        )
        Spacer(modifier = Modifier.height(32.dp))

        if (!isLoggedIn) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = CreamWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "Welcome to Shilpa Kala",
                        style = MaterialTheme.typography.titleLarge,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        color = DeepMaroon,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    var nameInput by remember { mutableStateOf("") }
                    var emailInput by remember { mutableStateOf("") }
                    var passwordInput by remember { mutableStateOf("") }
                    var addressInput by remember { mutableStateOf("") }

                    val fieldColors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = OchreGold,
                        unfocusedBorderColor = SoftGray,
                        focusedLabelColor = DeepMaroon,
                        cursorColor = DeepMaroon,
                        focusedTextColor = DeepMaroon
                    )

                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Full Name") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = fieldColors
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = { emailInput = it },
                        label = { Text("Gmail Address") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        colors = fieldColors
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        label = { Text("Password") },
                        modifier = Modifier.fillMaxWidth(),
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        colors = fieldColors
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = addressInput,
                        onValueChange = { addressInput = it },
                        label = { Text("Location Address") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = fieldColors
                    )
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                }
            }
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(
                    modifier = Modifier.size(100.dp),
                    shape = CircleShape,
                    color = OchreGold.copy(alpha = 0.1f),
                    border = BorderStroke(2.dp, OchreGold)
                ) {
                    Icon(Icons.Default.Person, null, modifier = Modifier.padding(20.dp), tint = DeepMaroon)
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    name.ifBlank { "Valued Member" },
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = DeepMaroon
                )
                Text(email, style = MaterialTheme.typography.bodyMedium, color = WarmGray)
                if (address.isNotBlank()) {
                    Text(address, style = MaterialTheme.typography.bodySmall, color = WarmGray, textAlign = TextAlign.Center)
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Orders Count Display
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = OchreGold.copy(alpha = 0.1f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ShoppingCart, null, tint = DeepMaroon)
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            "Total Orders Placed: $orderCount",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = DeepMaroon
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
                HorizontalDivider(color = SoftGray, thickness = 1.dp)
                
                ProfileOptionRow(Icons.Default.ShoppingBag, "My Orders") {}
                ProfileOptionRow(Icons.Default.LocationOn, "Addresses") {}
                ProfileOptionRow(Icons.Default.Payment, "Payment Methods") {}
                ProfileOptionRow(Icons.AutoMirrored.Filled.Help, "Help & Support") {
                    val intent = Intent(Intent.ACTION_VIEW, whatsappLink.toUri())
                    context.startActivity(intent)
                }
                
                Spacer(modifier = Modifier.height(40.dp))
                
                OutlinedButton(
                    onClick = onLogout,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, WarmRed),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = WarmRed)
                ) {
                    Text("SIGN OUT", fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(modifier = Modifier.height(100.dp))
    }
}

@Composable
fun ProfileOptionRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp)
            .clickable { onClick() },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = OchreGold, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, color = DeepMaroon)
        Spacer(modifier = Modifier.weight(1f))
        Icon(Icons.Default.ChevronRight, null, tint = SoftGray)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArtistsScreen(artistItems: SnapshotStateList<Sculpture>, navController: NavController) {
    var showAddDialog by remember { mutableStateOf(false) }
    var newTitle by remember { mutableStateOf("") }
    var newPrice by remember { mutableStateOf("") }
    var newDescription by remember { mutableStateOf("") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? -> selectedImageUri = uri }

    if (showAddDialog) {
        ModalBottomSheet(
            onDismissRequest = { showAddDialog = false },
            containerColor = CreamWhite,
            dragHandle = { BottomSheetDefaults.DragHandle(color = OchreGold) }
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(24.dp).verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Sell Your Masterpiece",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = DeepMaroon
                )
                Spacer(modifier = Modifier.height(24.dp))

                Box(
                    modifier = Modifier.size(150.dp).clip(RoundedCornerShape(16.dp)).background(SoftGray).clickable { launcher.launch("image/*") },
                    contentAlignment = Alignment.Center
                ) {
                    if (selectedImageUri != null) {
                        AsyncImage(model = selectedImageUri, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.AddPhotoAlternate, null, tint = WarmGray, modifier = Modifier.size(40.dp))
                            Text("Upload Image", style = MaterialTheme.typography.labelSmall, color = WarmGray)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                val customArtistFieldColors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OchreGold,
                    unfocusedBorderColor = SoftGray,
                    focusedLabelColor = DeepMaroon,
                    cursorColor = DeepMaroon,
                    focusedContainerColor = CreamWhite,
                    unfocusedContainerColor = CreamWhite,
                    focusedTextColor = WarmBrown,
                    unfocusedTextColor = WarmBrown
                )

                OutlinedTextField(value = newTitle, onValueChange = { newTitle = it }, label = { Text("Title of Artwork") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = customArtistFieldColors)
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(value = newPrice, onValueChange = { newPrice = it }, label = { Text("Amount / Price (e.g. ₹50,000)") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), colors = customArtistFieldColors)
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(value = newDescription, onValueChange = { newDescription = it }, label = { Text("Description & Details") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), minLines = 3, colors = customArtistFieldColors)
                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        if (newTitle.isNotBlank() && newPrice.isNotBlank() && selectedImageUri != null) {
                            val newSculpture = Sculpture(id = UUID.randomUUID().toString(), title = newTitle, artist = "Community Artist", collection = "Community Submissions", imageUrl = selectedImageUri.toString(), workId = "ART-${System.currentTimeMillis() % 10000}", material = "Mixed Material", description = newDescription, price = if (newPrice.startsWith("₹")) newPrice else "₹$newPrice", category = "Custom Orders", progress = 100, estCompletion = "Ready")
                            artistItems.add(0, newSculpture)
                            showAddDialog = false
                            newTitle = ""; newPrice = ""; newDescription = ""; selectedImageUri = null
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DeepMaroon)
                ) { Text("POST FOR SALE", fontWeight = FontWeight.Bold, color = CreamWhite) }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(CreamWhite)) {
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            item {
                Column(Modifier.padding(24.dp)) {
                    Text("Artist Community", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif, color = DeepMaroon)
                    Text("Showcase and sell your stone masterpieces.", color = WarmGray, style = MaterialTheme.typography.bodyMedium)
                }
            }

            if (artistItems.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(top = 100.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Brush, null, modifier = Modifier.size(64.dp), tint = SoftGray)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("No artist submissions yet.", color = WarmGray)
                        }
                    }
                }
            } else {
                items(artistItems) { sculpture -> SculptureCard(sculpture) { navController.navigate("detail/${sculpture.id}") } }
            }
            item { Spacer(modifier = Modifier.height(100.dp)) }
        }

        ExtendedFloatingActionButton(
            onClick = { showAddDialog = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 100.dp),
            containerColor = OchreGold,
            contentColor = CreamWhite,
            icon = { Icon(Icons.Default.Add, null, tint = CreamWhite) },
            text = { Text("Add Masterpiece", color = CreamWhite) }
        )
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun ShilpaKalaAppPreview() { MindmatrixTheme { ShilpaKalaApp() } }
