package com.example.mindmatrix.ui.theme

import androidx.compose.ui.graphics.Color

// Warmer Heritage Palette
val Primary = Color(0xFF5D4037) // Warm Brown
val OnPrimary = Color(0xFFFFFFFF)
val Secondary = Color(0xFFBC812C) // Ochre Gold
val OnSecondary = Color(0xFFFFFFFF)
val Tertiary = Color(0xFF8D6E63) // Lighter Warm Brown
val OnTertiary = Color(0xFFFFFFFF)

val Background = Color(0xFFFDF5E6) // Old Lace (Warmer Cream)
val OnBackground = Color(0xFF3E2723) // Deep Maroon/Dark Brown
val Surface = Color(0xFFFDF5E6)
val OnSurface = Color(0xFF3E2723)

val SurfaceContainer = Color(0xFFF5EBDC)
val OnSurfaceVariant = Color(0xFF5D4037)
val OutlineVariant = Color(0xFFD7CCC8)
val Error = Color(0xFFBA1A1A)

// Supplementary colors
val TertiaryFixedDim = Color(0xFFE9C176)
val SoftGray = Color(0xFFF5EBDC)   // Warm Beige
val WarmGray = Color(0xFF9E8E8A)   // Warm Gray for icons/secondary text
val WarmRed = Color(0xFFBA1A1A)
val SuccessGreen = Color(0xFF388E3C)

// Default colors
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650A4)
val PurpleGrey40 = Color(0xFF625B71)
val Pink40 = Color(0xFF7D5260)
